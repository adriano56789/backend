"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
// @ts-nocheck
const express_1 = __importDefault(require("express"));
const models_1 = require("../models");
const router = express_1.default.Router();
// GET /users/:id/frames - Retorna os frames do usuário
router.get('/users/:id/frames', async (req, res) => {
    try {
        const { id } = req.params;
        const user = await models_1.User.findOne({ id });
        if (!user) {
            return res.status(404).json({ error: 'Usuário não encontrado' });
        }
        // Filtrar frames que não expiraram
        const now = new Date();
        const activeFrames = (user.ownedFrames || []).filter((frame) => {
            const expirationDate = new Date(frame.expirationDate);
            return expirationDate > now;
        });
        res.json({
            ownedFrames: activeFrames,
            activeFrameId: user.activeFrameId,
            diamonds: user.diamonds
        });
    }
    catch (error) {
        console.error('Erro ao buscar frames do usuário:', error);
        res.status(500).json({ error: error.message });
    }
});
// POST /users/:id/frames/buy - Compra um frame
router.post('/users/:id/frames/buy', async (req, res) => {
    try {
        const { id } = req.params;
        const { frameId, price, duration } = req.body;
        if (!frameId || !price || !duration) {
            return res.status(400).json({ error: 'frameId, price e duration são obrigatórios' });
        }
        const user = await models_1.User.findOne({ id });
        if (!user) {
            return res.status(404).json({ error: 'Usuário não encontrado' });
        }
        // Verificar se usuário tem diamonds suficientes
        if (user.diamonds < price) {
            return res.status(400).json({ error: 'Diamonds insuficientes' });
        }
        // Verificar se já possui este frame
        const existingFrame = (user.ownedFrames || []).find((f) => f.frameId === frameId);
        if (existingFrame) {
            return res.status(400).json({ error: 'Você já possui este frame' });
        }
        // Adicionar frame ao usuário
        const expirationDate = new Date(Date.now() + duration * 24 * 60 * 60 * 1000);
        if (!user.ownedFrames) {
            user.ownedFrames = [];
        }
        user.ownedFrames.push({
            frameId,
            expirationDate: expirationDate.toISOString()
        });
        // Deduzir diamonds do comprador + persistir atividade
        user.diamonds -= price;
        user.recentActivities = user.recentActivities || [];
        user.recentActivities.push({
            action: 'purchase',
            resource: 'avatar_frame',
            timestamp: new Date(),
            endpoint: '/api/avatar/users/:id/frames/buy'
        });
        // Manter apenas as últimas 50 atividades
        if (user.recentActivities.length > 50) {
            user.recentActivities = user.recentActivities.slice(-50);
        }
        // Adicionar diamonds à carteira ADM (avatar é meu produto)
        const ADM_EMAIL = process.env.ADM_EMAIL || 'adrianomdk5@gmail.com';
        const admUser = await models_1.User.findOneAndUpdate({ email: ADM_EMAIL }, { $inc: { earnings: price } }, { returnDocument: 'after' });
        await user.save();
        // Registrar compra de avatar no histórico
        await models_1.PurchaseRecord.create({
            id: `avatar_${frameId}_${user.id}_${Date.now()}`,
            userId: user.id,
            type: 'avatar_purchase',
            description: `Compra de avatar/frame ${frameId} - ${price} diamantes`,
            amountBRL: 0, // Compra interna, não envolve dinheiro real
            amountCoins: price,
            status: 'Concluído',
            timestamp: new Date()
        });
        // Registrar receita para ADM
        if (admUser) {
            await models_1.PurchaseRecord.create({
                id: `avatar_fee_${frameId}_${user.id}_${Date.now()}`,
                userId: admUser.id,
                type: 'avatar_sale_income',
                description: `Venda de avatar ${frameId} para ${user.name}: ${price} diamantes`,
                amountBRL: 0,
                amountCoins: price,
                status: 'Concluído',
                timestamp: new Date()
            });
        }
        // Emitir WebSocket para atualização em tempo real
        const io = req.app.get('io');
        if (io) {
            io.to(user.id).emit('avatar_purchased', {
                userId: user.id,
                frameId,
                price,
                newDiamonds: user.diamonds
            });
            // Notificar ADM sobre nova receita
            if (admUser) {
                io.to(admUser.id).emit('earnings_updated', {
                    userId: admUser.id,
                    earnings: admUser.earnings,
                    change: price,
                    source: 'avatar_sale',
                    fromUser: user.name
                });
            }
        }
        res.json({
            success: true,
            user: {
                id: user.id,
                diamonds: user.diamonds,
                ownedFrames: user.ownedFrames,
                activeFrameId: user.activeFrameId
            }
        });
    }
    catch (error) {
        console.error('Erro ao comprar frame:', error);
        res.status(500).json({ error: error.message });
    }
});
// POST /users/:id/frames/equip - Equipa um frame
router.post('/users/:id/frames/equip', async (req, res) => {
    try {
        const { id } = req.params;
        const { frameId } = req.body;
        const user = await models_1.User.findOne({ id });
        if (!user) {
            return res.status(404).json({ error: 'Usuário não encontrado' });
        }
        // Verificar se o usuário possui este frame
        const ownedFrame = (user.ownedFrames || []).find((f) => f.frameId === frameId);
        if (!ownedFrame) {
            return res.status(400).json({ error: 'Você não possui este frame' });
        }
        // Verificar se o frame não expirou
        const expirationDate = new Date(ownedFrame.expirationDate);
        if (expirationDate <= new Date()) {
            return res.status(400).json({ error: 'Este frame expirou' });
        }
        // Equipar o frame
        user.activeFrameId = frameId;
        await user.save();
        res.json({
            success: true,
            user: {
                id: user.id,
                activeFrameId: user.activeFrameId,
                ownedFrames: user.ownedFrames
            }
        });
    }
    catch (error) {
        console.error('Erro ao equipar frame:', error);
        res.status(500).json({ error: error.message });
    }
});
// POST /users/:id/frames/unequip - Desequipa um frame
router.post('/users/:id/frames/unequip', async (req, res) => {
    try {
        const { id } = req.params;
        const user = await models_1.User.findOne({ id });
        if (!user) {
            return res.status(404).json({ error: 'Usuário não encontrado' });
        }
        // Desequipar o frame
        user.activeFrameId = null;
        await user.save();
        res.json({
            success: true,
            user: {
                id: user.id,
                activeFrameId: user.activeFrameId,
                ownedFrames: user.ownedFrames
            }
        });
    }
    catch (error) {
        console.error('Erro ao desequipar frame:', error);
        res.status(500).json({ error: error.message });
    }
});
// POST /users/:id/avatar-upload - Upload de avatar
router.post('/users/:id/avatar-upload', async (req, res) => {
    try {
        const { id } = req.params;
        if (!req.file) {
            return res.status(400).json({ error: 'Nenhuma imagem enviada' });
        }
        const user = await models_1.User.findOne({ id });
        if (!user) {
            return res.status(404).json({ error: 'Usuário não encontrado' });
        }
        // Gerar URL da imagem dinamicamente a partir da requisição
        const proto = req.headers['x-forwarded-proto'] || req.protocol || 'https';
        const host = req.headers['x-forwarded-host'] || req.get('host') || 'api.livego.store';
        const baseUrl = `${proto}://${host}`;
        const avatarUrl = `${baseUrl}/uploads/avatars/${req.file.filename}`;
        // Adicionar ao array de avatarImages
        if (!user.avatarImages) {
            user.avatarImages = [];
        }
        user.avatarImages.push(avatarUrl);
        // Adicionar também ao array de fotos do perfil
        if (!user.photos) {
            user.photos = [];
        }
        user.photos.push(avatarUrl);
        // Atualizar avatarUrl (campo usado pelo feed /video e outras telas)
        user.avatarUrl = avatarUrl;
        // Definir como avatar principal se for o primeiro
        if (!user.avatar || user.avatar.trim() === '') {
            user.avatar = avatarUrl;
        }
        await user.save();
        // Emitir evento WebSocket para atualização em tempo real do avatar
        try {
            const { getIO } = await Promise.resolve().then(() => __importStar(require('../socket')));
            const io = getIO();
            if (io) {
                io.to(`user_${id}`).emit('user_avatar_updated', {
                    userId: id,
                    avatarUrl
                });
            }
        }
        catch (err) {
            console.error('Erro ao emitir evento de avatar:', err);
        }
        res.json({
            success: true,
            avatarUrl,
            avatarImages: user.avatarImages,
            photos: user.photos
        });
    }
    catch (error) {
        console.error('Erro ao fazer upload de avatar:', error);
        res.status(500).json({ error: error.message });
    }
});
// GET /users/:id/avatars - Listar avatares do usuário
router.get('/users/:id/avatars', async (req, res) => {
    try {
        const { id } = req.params;
        const user = await models_1.User.findOne({ id }).select('avatar avatarImages');
        if (!user) {
            return res.status(404).json({ error: 'Usuário não encontrado' });
        }
        res.json({
            avatar: user.avatar,
            avatarImages: user.avatarImages || []
        });
    }
    catch (error) {
        console.error('Erro ao buscar avatares:', error);
        res.status(500).json({ error: error.message });
    }
});
// PUT /users/:id/avatar-main - Definir avatar principal
router.put('/users/:id/avatar-main', async (req, res) => {
    try {
        const { id } = req.params;
        const { avatarUrl } = req.body;
        if (!avatarUrl) {
            return res.status(400).json({ error: 'avatarUrl é obrigatório' });
        }
        const user = await models_1.User.findOne({ id });
        if (!user) {
            return res.status(404).json({ error: 'Usuário não encontrado' });
        }
        // Verificar se a imagem existe no array de avatares
        const hasAvatar = (user.avatarImages || []).includes(avatarUrl);
        if (!hasAvatar) {
            return res.status(400).json({ error: 'Avatar não encontrado na lista de avatares' });
        }
        user.avatar = avatarUrl;
        await user.save();
        res.json({
            success: true,
            avatar: user.avatar
        });
    }
    catch (error) {
        console.error('Erro ao definir avatar principal:', error);
        res.status(500).json({ error: error.message });
    }
});
// DELETE /users/:id/avatars/:index - Remover avatar
router.delete('/users/:id/avatars/:index', async (req, res) => {
    try {
        const { id, index } = req.params;
        const user = await models_1.User.findOne({ id });
        if (!user) {
            return res.status(404).json({ error: 'Usuário não encontrado' });
        }
        const avatarIndex = parseInt(index);
        if (isNaN(avatarIndex) || avatarIndex < 0 || !user.avatarImages || avatarIndex >= user.avatarImages.length) {
            return res.status(400).json({ error: 'Índice de avatar inválido' });
        }
        // Remover avatar do array
        user.avatarImages.splice(avatarIndex, 1);
        // Se o avatar removido era o principal, definir o próximo como principal
        if (user.avatar === user.avatarImages[avatarIndex]) {
            user.avatar = user.avatarImages.length > 0 ? user.avatarImages[0] : '';
        }
        await user.save();
        res.json({
            success: true,
            avatarImages: user.avatarImages,
            avatar: user.avatar
        });
    }
    catch (error) {
        console.error('Erro ao remover avatar:', error);
        res.status(500).json({ error: error.message });
    }
});
exports.default = router;
