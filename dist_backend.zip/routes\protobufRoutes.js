"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const fs_1 = __importDefault(require("fs"));
const path_1 = __importDefault(require("path"));
const router = express_1.default.Router();
router.get('/definition', async (req, res) => {
    try {
        const protoPath = path_1.default.join(__dirname, '../../protobuf/livego.proto');
        const content = fs_1.default.readFileSync(protoPath, 'utf-8');
        res.type('text/plain').send(content);
    }
    catch (error) {
        console.error('[Protobuf] Erro ao carregar definição:', error);
        res.status(404).json({ success: false, error: 'Protobuf definition not found' });
    }
});
exports.default = router;
