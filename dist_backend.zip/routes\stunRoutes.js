"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const router = express_1.default.Router();
const DEFAULT_STUN_SERVERS = [
    { urls: ['stun:stun.l.google.com:19302'], region: 'global' },
    { urls: ['stun:stun1.l.google.com:19302'], region: 'global' },
    { urls: ['stun:stun2.l.google.com:19302'], region: 'global' },
    { urls: ['stun:stun3.l.google.com:19302'], region: 'global' },
    { urls: ['stun:stun4.l.google.com:19302'], region: 'global' },
];
function getStunServersConfig() {
    const customStun = (process.env.STUN_URL);
    if (customStun) {
        return [
            ...DEFAULT_STUN_SERVERS,
            { urls: [customStun], region: 'custom' },
        ];
    }
    return DEFAULT_STUN_SERVERS;
}
// GET /api/stun/servers — Retorna lista de servidores STUN
router.get('/stun/servers', (_req, res) => {
    res.json({
        success: true,
        stunServers: getStunServersConfig(),
        timestamp: new Date().toISOString(),
    });
});
// POST /api/stun/discover — Descobrir IP público via STUN
router.post('/stun/discover', (req, res) => {
    const { stunUrl } = req.body;
    const clientIp = req.headers['x-forwarded-for'] || req.socket.remoteAddress || 'unknown';
    const ip = Array.isArray(clientIp) ? clientIp[0] : clientIp?.split(',')[0]?.trim() || 'unknown';
    res.json({
        success: true,
        ip,
        port: req.socket.remotePort || 0,
        stunServer: stunUrl || 'stun:stun.l.google.com:19302',
        natType: 'unknown', // Seria determinado por probing STUN real
        timestamp: new Date().toISOString(),
    });
});
exports.default = router;
