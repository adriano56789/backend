"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const livekit_server_sdk_1 = require("livekit-server-sdk");
const env_1 = require("../config/env");
const router = express_1.default.Router();
// LiveKit Server SDK client
const livekitHost = env_1.ENV.LIVEKIT_URL?.replace('wss://', '').replace('ws://', '') || 'sfu.livego.store';
const roomService = new livekit_server_sdk_1.RoomServiceClient(`https://${livekitHost}`, env_1.ENV.LIVEKIT_API_KEY, env_1.ENV.LIVEKIT_API_SECRET);
const fallbackRooms = new Map();
// Helper: gerar token de acesso LiveKit
async function generateLiveKitToken(identity, room, metadata) {
    const at = new livekit_server_sdk_1.AccessToken(env_1.ENV.LIVEKIT_API_KEY, env_1.ENV.LIVEKIT_API_SECRET, {
        identity,
        ttl: '6h',
        metadata,
    });
    at.addGrant({ roomJoin: true, room });
    return at.toJwt();
}
// GET /api/livekit/token - Gerar token de acesso
router.get('/token', async (req, res) => {
    const identity = req.query.identity || `user_${Date.now()}`;
    const room = req.query.room || `room_${Date.now()}`;
    const metadata = req.query.metadata;
    try {
        const token = await generateLiveKitToken(identity, room, metadata);
        res.json({
            success: true,
            token,
            identity,
            room,
            livekitUrl: env_1.ENV.LIVEKIT_URL,
        });
    }
    catch (error) {
        console.error('[LIVEKIT] Erro ao gerar token:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});
// POST /api/livekit/token - Gerar token via POST
router.post('/token', async (req, res) => {
    const { identity, room, metadata } = req.body;
    if (!identity || !room) {
        return res.status(400).json({ error: 'identity and room are required' });
    }
    try {
        const token = await generateLiveKitToken(identity, room, metadata);
        res.json({
            success: true,
            token,
            identity,
            room,
            livekitUrl: env_1.ENV.LIVEKIT_URL,
        });
    }
    catch (error) {
        console.error('[LIVEKIT] Erro ao gerar token:', error);
        res.status(500).json({ success: false, error: error.message });
    }
});
// POST /api/livekit/rooms - Criar sala no LiveKit
router.post('/rooms', async (req, res) => {
    const { name, emptyTimeout = 300, maxParticipants = 50 } = req.body;
    if (!name)
        return res.status(400).json({ error: 'Room name required' });
    try {
        // Tentar criar no LiveKit Server
        await roomService.createRoom({
            name,
            emptyTimeout,
            maxParticipants,
        });
        console.log(`[LIVEKIT] Sala criada no LiveKit: ${name}`);
        res.json({
            success: true,
            room: { name, emptyTimeout, maxParticipants, createdAt: new Date() },
        });
    }
    catch (error) {
        console.warn(`[LIVEKIT] Fallback para sala em memória (LiveKit indisponível): ${error.message}`);
        // Fallback: sala em memória
        if (fallbackRooms.has(name)) {
            return res.status(409).json({ error: 'Room already exists' });
        }
        const room = {
            name,
            emptyTimeout,
            maxParticipants,
            createdAt: new Date(),
            participants: new Map(),
        };
        fallbackRooms.set(name, room);
        res.json({
            success: true,
            room: {
                name,
                emptyTimeout,
                maxParticipants,
                createdAt: room.createdAt,
                participantCount: 0,
            },
        });
    }
});
// POST /api/livekit/rooms/:roomName/join - Entrar na sala
router.post('/rooms/:roomName/join', async (req, res) => {
    const { roomName } = req.params;
    const { identity, name, role = 'participant' } = req.body;
    if (!identity)
        return res.status(400).json({ error: 'Identity required' });
    const room = fallbackRooms.get(roomName);
    if (!room)
        return res.status(404).json({ error: 'Room not found' });
    if (room.participants.size >= room.maxParticipants) {
        return res.status(403).json({ error: 'Room is full' });
    }
    const participant = {
        identity,
        name: name || identity,
        role,
        joinedAt: new Date(),
        tracks: [],
    };
    room.participants.set(identity, participant);
    console.log(`[LIVEKIT] Participante ${identity} entrou na sala ${roomName}`);
    // Gerar token LiveKit para este participante
    const token = await generateLiveKitToken(identity, roomName);
    res.json({
        success: true,
        room: { name: roomName, participantCount: room.participants.size },
        participant: { identity, name: participant.name, role },
        token,
        livekitUrl: env_1.ENV.LIVEKIT_URL,
    });
});
// POST /api/livekit/rooms/:roomName/participants/:identity/tracks - Publicar track
router.post('/rooms/:roomName/participants/:identity/tracks', (req, res) => {
    const { roomName, identity } = req.params;
    const { sid, source, muted = false } = req.body;
    const room = fallbackRooms.get(roomName);
    if (!room)
        return res.status(404).json({ error: 'Room not found' });
    const participant = room.participants.get(identity);
    if (!participant)
        return res.status(404).json({ error: 'Participant not found' });
    participant.tracks.push({ sid, source, muted });
    console.log(`[LIVEKIT] Track ${sid} (${source}) publicada por ${identity} em ${roomName}`);
    res.json({ success: true, track: { sid, source, muted } });
});
// GET /api/livekit/rooms - Listar salas
router.get('/rooms', async (req, res) => {
    try {
        // Tentar listar do LiveKit Server
        const liveRooms = await roomService.listRooms();
        const roomList = liveRooms.map(r => ({
            name: r.name,
            emptyTimeout: r.emptyTimeout,
            maxParticipants: r.maxParticipants,
            createdAt: new Date(Number(r.creationTimeMs ?? r.creationTime)),
            participantCount: r.numParticipants || 0,
        }));
        res.json({ success: true, rooms: roomList, source: 'livekit' });
    }
    catch (error) {
        // Fallback: listar salas em memória
        const roomList = Array.from(fallbackRooms.values()).map(r => ({
            name: r.name,
            emptyTimeout: r.emptyTimeout,
            maxParticipants: r.maxParticipants,
            createdAt: r.createdAt,
            participantCount: r.participants.size,
        }));
        res.json({ success: true, rooms: roomList, source: 'memory' });
    }
});
// DELETE /api/livekit/rooms/:roomName - Deletar sala
router.delete('/rooms/:roomName', async (req, res) => {
    const { roomName } = req.params;
    try {
        await roomService.deleteRoom(roomName);
        console.log(`[LIVEKIT] Sala ${roomName} deletada do LiveKit`);
        res.json({ success: true, source: 'livekit' });
    }
    catch (error) {
        // Fallback: remover da memória
        const deleted = fallbackRooms.delete(roomName);
        console.log(`[LIVEKIT] Sala ${roomName} ${deleted ? 'deletada' : 'não encontrada'} (memória)`);
        res.json({ success: deleted, source: 'memory' });
    }
});
// GET /api/livekit/rooms/:roomName/participants - Listar participantes
router.get('/rooms/:roomName/participants', async (req, res) => {
    const { roomName } = req.params;
    try {
        const participants = await roomService.listParticipants(roomName);
        const list = participants.map(p => ({
            identity: p.identity,
            name: p.name,
            joinedAt: p.joinedAt,
            trackCount: p.tracks?.length || 0,
        }));
        res.json({ success: true, participants: list, source: 'livekit' });
    }
    catch (error) {
        // Fallback: participantes em memória
        const room = fallbackRooms.get(roomName);
        if (!room)
            return res.status(404).json({ error: 'Room not found' });
        const list = Array.from(room.participants.values()).map(p => ({
            identity: p.identity,
            name: p.name,
            role: p.role,
            joinedAt: p.joinedAt,
            trackCount: p.tracks.length,
        }));
        res.json({ success: true, participants: list, source: 'memory' });
    }
});
// GET /api/livekit/rooms/:roomName/participants/:identity - Buscar participante
router.get('/rooms/:roomName/participants/:identity', (req, res) => {
    const { roomName, identity } = req.params;
    const room = fallbackRooms.get(roomName);
    if (!room)
        return res.status(404).json({ error: 'Room not found' });
    const participant = room.participants.get(identity);
    if (!participant)
        return res.status(404).json({ error: 'Participant not found' });
    res.json({
        success: true,
        participant: {
            identity: participant.identity,
            name: participant.name,
            role: participant.role,
            joinedAt: participant.joinedAt,
            tracks: participant.tracks,
        },
    });
});
// POST /api/livekit/rooms/:roomName/participants/:identity/kick - Remover participante
router.post('/rooms/:roomName/participants/:identity/kick', async (req, res) => {
    const { roomName, identity } = req.params;
    try {
        await roomService.removeParticipant(roomName, identity);
        console.log(`[LIVEKIT] Participante ${identity} removido da sala ${roomName} (LiveKit)`);
        res.json({ success: true, source: 'livekit' });
    }
    catch (error) {
        // Fallback: remover da memória
        const room = fallbackRooms.get(roomName);
        if (!room)
            return res.status(404).json({ error: 'Room not found' });
        const removed = room.participants.delete(identity);
        console.log(`[LIVEKIT] Participante ${identity} ${removed ? 'removido' : 'não encontrado'} da sala ${roomName}`);
        res.json({ success: removed, source: 'memory' });
    }
});
// POST /api/livekit/rooms/:roomName/participants/:identity/tracks/:trackSid/mute - Mutar track
router.post('/rooms/:roomName/participants/:identity/tracks/:trackSid/mute', async (req, res) => {
    const { roomName, identity, trackSid } = req.params;
    const { muted } = req.body;
    try {
        if (muted) {
            await roomService.mutePublishedTrack(roomName, identity, trackSid, true);
        }
        console.log(`[LIVEKIT] Track ${trackSid} ${muted ? 'mutada' : 'desmutada'} para ${identity}`);
        res.json({ success: true, source: 'livekit' });
    }
    catch (error) {
        // Fallback: mutar em memória
        const room = fallbackRooms.get(roomName);
        if (!room)
            return res.status(404).json({ error: 'Room not found' });
        const participant = room.participants.get(identity);
        if (!participant)
            return res.status(404).json({ error: 'Participant not found' });
        const track = participant.tracks.find(t => t.sid === trackSid);
        if (!track)
            return res.status(404).json({ error: 'Track not found' });
        track.muted = muted;
        res.json({ success: true, source: 'memory' });
    }
});
// POST /api/livekit/rooms/:roomName/participants/:identity/update - Atualizar participante
router.post('/rooms/:roomName/participants/:identity/update', (req, res) => {
    const { roomName, identity } = req.params;
    const { metadata } = req.body;
    const room = fallbackRooms.get(roomName);
    if (!room)
        return res.status(404).json({ error: 'Room not found' });
    const participant = room.participants.get(identity);
    if (!participant)
        return res.status(404).json({ error: 'Participant not found' });
    if (metadata !== undefined)
        participant.metadata = metadata;
    res.json({ success: true });
});
exports.default = router;
