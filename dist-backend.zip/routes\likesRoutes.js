"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const models_1 = require("../models");
const router = express_1.default.Router();
// Parameter middleware to normalize stream IDs (remove 'stream_' prefix if present)
router.param('id', (req, res, next, val) => {
    if (val && typeof val === 'string' && val.startsWith('stream_')) {
        req.params.id = val.replace('stream_', '');
    }
    next();
});
// POST /api/streams/:id/like - Adicionar curtida na transmissão
router.post('/streams/:id/like', async (req, res) => {
    try {
        const { id: streamId } = req.params;
        const userId = req.body.userId;
        if (!userId) {
            return res.status(400).json({ error: 'ID do usuário é obrigatório' });
        }
        // Verificar se a transmissão existe
        const streamer = await models_1.Streamer.findOne({ id: streamId });
        if (!streamer) {
            return res.status(404).json({ error: 'Transmissão não encontrada' });
        }
        // Incrementar contador de curtidas no banco de dados + persistir atividade do usuário
        const currentLikes = streamer.likes || 0;
        const newLikes = currentLikes + 1;
        await models_1.Streamer.updateOne({ id: streamId }, { $set: { likes: newLikes } });
        // Persistir atividade do usuário que curtiu
        await models_1.User.findOneAndUpdate({ id: userId }, {
            $push: {
                recentActivities: {
                    action: 'like',
                    resource: 'content_engagement',
                    timestamp: new Date(),
                    endpoint: '/api/streams/:id/like'
                }
            }
        });
        // Emitir WebSocket para atualização em tempo real
        const io = req.app.get('io');
        if (io) {
            io.to(streamId).emit('stream_liked', {
                streamId,
                totalLikes: newLikes,
                userId: userId
            });
        }
        // === NOTIFICAR DONO DA STREAM via serviço centralizado ===
        try {
            const { NotificationService } = await Promise.resolve().then(() => __importStar(require('../services/NotificationService')));
            await NotificationService.notifyStreamLiked(io, streamer.hostId, userId, streamId);
        }
        catch (notifErr) {
            console.warn('[STREAM-LIKE-NOTIFICATION] Erro:', notifErr);
        }
        res.json({
            success: true,
            totalLikes: newLikes,
            message: 'Curtida registrada com sucesso'
        });
    }
    catch (error) {
        console.error('Erro ao registrar curtida:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
});
// GET /api/streams/:id/likes - Obter contador de curtidas
router.get('/streams/:id/likes', async (req, res) => {
    try {
        const { id: streamId } = req.params;
        console.log(`[LIKES-API] Buscando likes para stream: ${streamId}`);
        console.log(`[LIKES-API] User-Agent: ${req.get('User-Agent')}`);
        console.log(`[LIKES-API] Timestamp: ${new Date().toISOString()}`);
        // Verificar se a transmissão existe
        const streamer = await models_1.Streamer.findOne({ id: streamId });
        console.log(`[LIKES-API] Stream encontrada no banco: ${streamer ? 'SIM' : 'NÃO'}`);
        if (!streamer) {
            console.log(`[LIKES-API] ERRO 404 - Stream não encontrada: ${streamId}`);
            // Buscar todas as streams para debug
            const allStreams = await models_1.Streamer.find({}).select('id isLive hostId name').limit(10);
            console.log(`[LIKES-API] Streams disponíveis no banco:`, allStreams.map(s => ({ id: s.id, isLive: s.isLive, hostId: s.hostId, name: s.name })));
            return res.status(404).json({ error: 'Transmissão não encontrada' });
        }
        // Retornar contador de curtidas do banco de dados
        const totalLikes = streamer.likes || 0;
        console.log(`[LIKES-API] Likes encontrados: ${totalLikes}, isLive: ${streamer.isLive}`);
        res.json({
            streamId,
            totalLikes,
            isLive: streamer.isLive
        });
    }
    catch (error) {
        console.error('[LIKES-API] Erro ao obter curtidas:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
});
// POST /api/streams/:id/likes/reset - Resetar contador (apenas para o streamer)
router.post('/streams/:id/likes/reset', async (req, res) => {
    try {
        const { id: streamId } = req.params;
        const { userId } = req.body;
        if (!userId) {
            return res.status(400).json({ error: 'ID do usuário é obrigatório' });
        }
        // Verificar se o usuário é o dono da transmissão
        const streamer = await models_1.Streamer.findOne({ id: streamId, hostId: userId });
        if (!streamer) {
            return res.status(403).json({ error: 'Apenas o dono da transmissão pode resetar as curtidas' });
        }
        // Resetar contador no banco de dados
        await models_1.Streamer.updateOne({ id: streamId }, { $set: { likes: 0 } });
        // Emitir WebSocket para atualização em tempo real
        const io = req.app.get('io');
        if (io) {
            io.to(streamId).emit('stream_likes_reset', {
                streamId,
                totalLikes: 0
            });
        }
        res.json({
            success: true,
            totalLikes: 0,
            message: 'Contador de curtidas resetado com sucesso'
        });
    }
    catch (error) {
        console.error('Erro ao resetar curtidas:', error);
        res.status(500).json({ error: 'Erro interno do servidor' });
    }
});
exports.default = router;
