"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const models_1 = require("../models");
const router = express_1.default.Router();
// Upload de foto do usuário
router.post('/users/:userId/photos', async (req, res) => {
    try {
        const { userId } = req.params;
        const { photoUrl, caption, tags, isPublic } = req.body;
        // Verificar se usuário existe
        const user = await models_1.User.findOne({ id: userId });
        if (!user) {
            return res.status(404).json({ error: 'Usuário não encontrado' });
        }
        // Criar registro da foto + persistir atividade
        const photo = await models_1.UserPhoto.create({
            id: `photo_${userId}_${Date.now()}`,
            userId,
            photoUrl,
            caption: caption || '',
            tags: tags || [],
            isPublic: isPublic !== false
        });
        // Persistir atividade de upload de foto
        await models_1.User.findOneAndUpdate({ id: userId }, {
            $push: {
                recentActivities: {
                    action: 'photo_uploaded',
                    resource: 'media_content',
                    timestamp: new Date(),
                    endpoint: '/api/media/users/:userId/photos'
                }
            }
        }).catch(console.error);
        // Atualizar avatar do usuário se for a primeira foto ou se marcado como avatar
        if (!user.avatarUrl || req.body.isAvatar) {
            // VALIDAÇÃO: Bloquear URLs Base64 - apenas permitir URLs normais
            if (photoUrl && photoUrl.startsWith('data:image')) {
                return res.status(400).json({
                    success: false,
                    error: 'URLs Base64 não são permitidas. Use o upload de arquivos.'
                });
            }
            await models_1.User.findOneAndUpdate({ id: userId }, { $set: { avatarUrl: photoUrl } });
            // Registrar atualização de perfil
            await models_1.ProfileUpdate.create({
                id: `profile_update_${userId}_${Date.now()}`,
                userId,
                updateType: 'avatar',
                oldValue: user.avatarUrl,
                newValue: photoUrl,
                updateReason: 'Nova foto de perfil'
            });
        }
        res.json({ success: true, photo });
    }
    catch (error) {
        console.error('Erro ao fazer upload de foto:', error);
        res.status(500).json({ error: error.message });
    }
});
// Upload de vídeo do usuário
router.post('/users/:userId/videos', async (req, res) => {
    try {
        const { userId } = req.params;
        const { videoUrl, thumbnailUrl, title, description, duration, tags, isPublic } = req.body;
        // Verificar se usuário existe
        const user = await models_1.User.findOne({ id: userId });
        if (!user) {
            return res.status(404).json({ error: 'Usuário não encontrado' });
        }
        // Criar registro do vídeo + persistir atividade
        const video = await models_1.UserVideo.create({
            id: `video_${userId}_${Date.now()}`,
            userId,
            videoUrl,
            thumbnailUrl,
            title,
            description: description || '',
            duration,
            tags: tags || [],
            isPublic: isPublic !== false
        });
        // Persistir atividade de upload de vídeo
        await models_1.User.findOneAndUpdate({ id: userId }, {
            $push: {
                recentActivities: {
                    action: 'video_uploaded',
                    resource: 'media_content',
                    timestamp: new Date(),
                    endpoint: '/api/media/users/:userId/videos'
                }
            }
        }).catch(console.error);
        res.json({ success: true, video });
    }
    catch (error) {
        console.error('Erro ao fazer upload de vídeo:', error);
        res.status(500).json({ error: error.message });
    }
});
// Buscar fotos de um usuário
router.get('/users/:userId/photos', async (req, res) => {
    try {
        const { userId } = req.params;
        const { page = 1, limit = 20 } = req.query;
        // Persistir atividade de consulta de fotos
        await models_1.User.findOneAndUpdate({ id: userId }, {
            $push: {
                recentActivities: {
                    action: 'photos_viewed',
                    resource: 'media_content',
                    timestamp: new Date(),
                    endpoint: '/api/media/users/:userId/photos'
                }
            }
        }).catch(console.error);
        const photos = await models_1.UserPhoto.find({
            userId,
            isPublic: true
        })
            .sort({ postedAt: -1 })
            .limit(Number(limit) * Number(page))
            .skip((Number(page) - 1) * Number(limit));
        const total = await models_1.UserPhoto.countDocuments({
            userId,
            isPublic: true
        });
        res.json({
            photos,
            pagination: {
                page: Number(page),
                limit: Number(limit),
                total,
                pages: Math.ceil(total / Number(limit))
            }
        });
    }
    catch (error) {
        console.error('Erro ao buscar fotos:', error);
        res.status(500).json({ error: error.message });
    }
});
// Buscar vídeos de um usuário
router.get('/users/:userId/videos', async (req, res) => {
    try {
        const { userId } = req.params;
        const { page = 1, limit = 20 } = req.query;
        // Persistir atividade de consulta de vídeos
        await models_1.User.findOneAndUpdate({ id: userId }, {
            $push: {
                recentActivities: {
                    action: 'videos_viewed',
                    resource: 'media_content',
                    timestamp: new Date(),
                    endpoint: '/api/media/users/:userId/videos'
                }
            }
        }).catch(console.error);
        const videos = await models_1.UserVideo.find({
            userId,
            isPublic: true
        })
            .sort({ postedAt: -1 })
            .limit(Number(limit) * Number(page))
            .skip((Number(page) - 1) * Number(limit));
        const total = await models_1.UserVideo.countDocuments({
            userId,
            isPublic: true
        });
        res.json({
            videos,
            pagination: {
                page: Number(page),
                limit: Number(limit),
                total,
                pages: Math.ceil(total / Number(limit))
            }
        });
    }
    catch (error) {
        console.error('Erro ao buscar vídeos:', error);
        res.status(500).json({ error: error.message });
    }
});
// Atualizar perfil do usuário
router.put('/users/:userId/profile', async (req, res) => {
    try {
        const { userId } = req.params;
        const { name, avatarUrl, bio } = req.body;
        // Verificar se usuário existe
        const user = await models_1.User.findOne({ id: userId });
        if (!user) {
            return res.status(404).json({ error: 'Usuário não encontrado' });
        }
        // Atualizar dados
        const updateData = {};
        const updates = [];
        if (name && name !== user.name) {
            updateData.name = name;
            updates.push({
                id: `profile_update_${userId}_${Date.now()}_1`,
                userId,
                updateType: 'info',
                oldValue: user.name,
                newValue: name,
                updateReason: 'Atualização de nome'
            });
        }
        if (avatarUrl && avatarUrl !== user.avatarUrl) {
            // VALIDAÇÃO: Bloquear URLs Base64 - apenas permitir URLs normais
            if (avatarUrl && avatarUrl.startsWith('data:image')) {
                return res.status(400).json({
                    success: false,
                    error: 'URLs Base64 não são permitidas. Use o upload de arquivos.'
                });
            }
            updateData.avatarUrl = avatarUrl;
            updates.push({
                id: `profile_update_${userId}_${Date.now()}_2`,
                userId,
                updateType: 'avatar',
                oldValue: user.avatarUrl,
                newValue: avatarUrl,
                updateReason: 'Atualização de avatar'
            });
        }
        if (bio && bio !== user.bio) {
            updateData.bio = bio;
            updates.push({
                id: `profile_update_${userId}_${Date.now()}_3`,
                userId,
                updateType: 'info',
                oldValue: user.bio,
                newValue: bio,
                updateReason: 'Atualização de bio'
            });
        }
        // Atualizar usuário + persistir atividade
        await models_1.User.findOneAndUpdate({ id: userId }, {
            $set: {
                ...updateData
            },
            $push: {
                recentActivities: {
                    action: 'profile_updated',
                    resource: 'user_profile',
                    timestamp: new Date(),
                    endpoint: '/api/media/users/:userId/profile'
                }
            }
        });
        // Salvar histórico de atualizações
        if (updates.length > 0) {
            await models_1.ProfileUpdate.insertMany(updates);
        }
        res.json({ success: true, updated: updateData });
    }
    catch (error) {
        console.error('Erro ao atualizar perfil:', error);
        res.status(500).json({ error: error.message });
    }
});
// Buscar histórico de atualizações do perfil
router.get('/users/:userId/profile-updates', async (req, res) => {
    try {
        const { userId } = req.params;
        const { page = 1, limit = 20 } = req.query;
        // Persistir atividade de consulta de histórico
        await models_1.User.findOneAndUpdate({ id: userId }, {
            $push: {
                recentActivities: {
                    action: 'profile_history_viewed',
                    resource: 'user_profile',
                    timestamp: new Date(),
                    endpoint: '/api/media/users/:userId/profile-updates'
                }
            }
        }).catch(console.error);
        const updates = await models_1.ProfileUpdate.find({ userId })
            .sort({ updatedAt: -1 })
            .limit(Number(limit) * Number(page))
            .skip((Number(page) - 1) * Number(page));
        const total = await models_1.ProfileUpdate.countDocuments({ userId });
        res.json({
            updates,
            pagination: {
                page: Number(page),
                limit: Number(limit),
                total,
                pages: Math.ceil(total / Number(limit))
            }
        });
    }
    catch (error) {
        console.error('Erro ao buscar atualizações:', error);
        res.status(500).json({ error: error.message });
    }
});
exports.default = router;
