"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.onlineTracker = void 0;
const StreamParticipant_1 = require("../models/StreamParticipant");
const models_1 = require("../models");
const Streamer_1 = require("../models/Streamer");
class OnlineTracker {
    async userJoin(streamId, userId, hostId, userName, userAvatar) {
        let role = 'visitor';
        if (userId === hostId) {
            role = 'host';
        }
        else {
            const isFan = !!(await models_1.Followers.exists({
                followerId: userId,
                followingId: hostId,
                isActive: true
            }));
            role = isFan ? 'fan' : 'visitor';
        }
        await StreamParticipant_1.StreamParticipant.findOneAndUpdate({ streamId, userId }, {
            $set: { streamId, userId, role, userName, userAvatar, joinedAt: new Date() }
        }, { upsert: true, new: true });
        const [fans, visitors] = await Promise.all([
            StreamParticipant_1.StreamParticipant.countDocuments({ streamId, role: 'fan' }),
            StreamParticipant_1.StreamParticipant.countDocuments({ streamId, role: 'visitor' })
        ]);
        // Persistir no documento da stream
        await Streamer_1.Streamer.findOneAndUpdate({ id: streamId }, { $set: { onlineFans: fans, onlineVisitors: visitors } }).catch(() => { });
        return { role, fans, visitors };
    }
    async userLeave(streamId, userId) {
        await StreamParticipant_1.StreamParticipant.findOneAndDelete({ streamId, userId });
        const [fans, visitors] = await Promise.all([
            StreamParticipant_1.StreamParticipant.countDocuments({ streamId, role: 'fan' }),
            StreamParticipant_1.StreamParticipant.countDocuments({ streamId, role: 'visitor' })
        ]);
        await Streamer_1.Streamer.findOneAndUpdate({ id: streamId }, { $set: { onlineFans: fans, onlineVisitors: visitors } }).catch(() => { });
        return { fans, visitors };
    }
    async getCounts(streamId) {
        const [fans, visitors] = await Promise.all([
            StreamParticipant_1.StreamParticipant.countDocuments({ streamId, role: 'fan' }),
            StreamParticipant_1.StreamParticipant.countDocuments({ streamId, role: 'visitor' })
        ]);
        return { fans, visitors, total: fans + visitors };
    }
    async getAllCounts() {
        const [fans, visitors] = await Promise.all([
            StreamParticipant_1.StreamParticipant.countDocuments({ role: 'fan' }),
            StreamParticipant_1.StreamParticipant.countDocuments({ role: 'visitor' })
        ]);
        return { fans, visitors, total: fans + visitors };
    }
    async getStreams() {
        const result = await StreamParticipant_1.StreamParticipant.distinct('streamId');
        return result;
    }
}
exports.onlineTracker = new OnlineTracker();
