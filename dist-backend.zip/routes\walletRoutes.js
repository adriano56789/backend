"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
const express_1 = __importDefault(require("express"));
const models_1 = require("../models");
const diamondConversion_1 = require("../utils/diamondConversion");
const fraudDetection_1 = __importDefault(require("../middleware/fraudDetection"));
const mercadoPagoService_1 = __importDefault(require("../services/mercadoPagoService"));
const auth_1 = require("../middleware/auth");
const rateLimit_1 = require("../middleware/rateLimit");
const env_1 = require("../config/env");
const router = express_1.default.Router();
router.get('/purchases/history/:id', async (req, res) => {
    // Persistir atividade de consulta de histórico de compras
    await models_1.User.findOneAndUpdate({ id: req.params.id }, {
        $push: {
            recentActivities: {
                action: 'purchase_history_viewed',
                resource: 'wallet',
                timestamp: new Date(),
                endpoint: '/api/wallet/purchases/history/:id'
            }
        }
    }).catch(console.error);
    const history = await models_1.PurchaseRecord.find({ userId: req.params.id }).sort({ timestamp: -1 });
    res.json(history);
});
router.get('/earnings/get/:id', async (req, res) => {
    try {
        const user = await Promise.resolve().then(() => __importStar(require('../models'))).then(m => m.User).then(U => U.findOne({ id: req.params.id }));
        if (!user)
            return res.status(404).json({ error: 'Usuário não encontrado' });
        // Persistir atividade de consulta de earnings
        await models_1.User.findOneAndUpdate({ id: req.params.id }, {
            $push: {
                recentActivities: {
                    action: 'earnings_viewed',
                    resource: 'wallet',
                    timestamp: new Date(),
                    endpoint: '/api/wallet/earnings/get/:id'
                }
            }
        }).catch(console.error);
        // Garantir que earnings seja sempre um número inteiro
        const available_diamonds = Math.floor(user.earnings || 0);
        const brl_value = (0, diamondConversion_1.calculateBRLFromDiamonds)(available_diamonds);
        console.log(`💳 [EARNINGS] Usuário ${user.name} (${req.params.id}) - Earnings: ${available_diamonds} diamantes`);
        res.json({
            available_diamonds,
            brl_value,
            conversion_rate: 'Tabela de pacotes',
            withdrawal_method: user.withdrawal_method || null
        });
    }
    catch (error) {
        console.error('❌ [EARNINGS] Erro ao buscar earnings:', error);
        res.status(500).json({ error: error.message });
    }
});
// Calcular valores de saque
router.post('/earnings/calculate', async (req, res) => {
    try {
        const { amount, userId } = req.body;
        if (!amount || amount <= 0 || !userId) {
            return res.status(400).json({ error: 'Valor e userId são obrigatórios' });
        }
        // Persistir atividade de cálculo de saque
        await models_1.User.findOneAndUpdate({ id: userId }, {
            $push: {
                recentActivities: {
                    action: 'withdrawal_calculated',
                    resource: 'wallet',
                    timestamp: new Date(),
                    endpoint: '/api/wallet/earnings/calculate'
                }
            }
        }).catch(console.error);
        // Calcular valores (sem taxa - apenas conversão)
        const brl_amount = (0, diamondConversion_1.calculateBRLFromDiamonds)(amount);
        const platform_fee_brl = Math.round((brl_amount * 0.20) * 100) / 100; // Mostrar taxa informativa
        const net_brl = Math.round((brl_amount - platform_fee_brl) * 100) / 100; // Valor que receberia ao sacar
        // ⚠️ REMOVIDO: Logs com dados sensíveis
        // console.log(`[CALCULATE] Valores do saque:`);
        // console.log(`[CALCULATE] - Valor bruto: R$ ${brl_amount.toFixed(2)}`);
        // console.log(`[CALCULATE] - Taxa plataforma (20%): R$ ${platform_fee_brl.toFixed(2)}`);
        // console.log(`[CALCULATE] - Valor líquido: R$ ${net_brl.toFixed(2)}`);
        console.log('[CALCULATE] Cálculo de saque processado para amount:', amount);
        res.json({
            diamonds: amount,
            gross_brl: brl_amount,
            platform_fee_brl: parseFloat(platform_fee_brl.toFixed(2)),
            net_brl: parseFloat(net_brl.toFixed(2)),
            breakdown: {
                conversion: `${amount} diamantes = R$ ${brl_amount.toFixed(2)}`,
                fee: `Taxa de saque (20%): R$ ${platform_fee_brl.toFixed(2)}`,
                final: `Você receberia: R$ ${net_brl.toFixed(2)}`
            }
        });
    }
    catch (error) {
        console.error('❌ [CALCULATE] Erro ao calcular saque:', error);
        res.status(500).json({ error: error.message });
    }
});
// API para validar e sincronizar contadores de presentes do usuário
router.get('/gifts/validate/:userId', async (req, res) => {
    try {
        const userId = req.params.userId;
        console.log(`🔍 [VALIDATE] Validando contadores de presentes para usuário: ${userId}`);
        // Persistir atividade de validação de presentes
        await models_1.User.findOneAndUpdate({ id: userId }, {
            $push: {
                recentActivities: {
                    action: 'gift_counters_validated',
                    resource: 'wallet',
                    timestamp: new Date(),
                    endpoint: '/api/wallet/gifts/validate/:userId'
                }
            }
        }).catch(console.error);
        // Buscar usuário com projeção apenas para dados financeiros
        const user = await models_1.User.findOne({ id: userId }).select('id diamonds earnings withdrawal_method name email');
        if (!user) {
            return res.status(404).json({ error: 'Usuário não encontrado' });
        }
        // Calcular valores reais baseados nas transações
        const sentTransactions = await models_1.GiftTransaction.find({ fromUserId: userId });
        const receivedTransactions = await models_1.GiftTransaction.find({ toUserId: userId });
        // Somar totais reais
        const realEnviados = sentTransactions.reduce((sum, transaction) => sum + (transaction.totalValue || 0), 0);
        const realReceptores = receivedTransactions.reduce((sum, transaction) => sum + (transaction.totalValue || 0), 0);
        // Valores atuais no perfil
        const currentEnviados = user.enviados || 0;
        const currentReceptores = user.receptores || 0;
        console.log(`📊 [VALIDATE] Usuário: ${userId}`);
        console.log(`📤 [VALIDATE] Enviados - Atual: ${currentEnviados}, Real: ${realEnviados}, Diff: ${realEnviados - currentEnviados}`);
        console.log(`📥 [VALIDATE] Receptores - Atual: ${currentReceptores}, Real: ${realReceptores}, Diff: ${realReceptores - currentReceptores}`);
        console.log(`📝 [VALIDATE] Transações enviadas: ${sentTransactions.length}, recebidas: ${receivedTransactions.length}`);
        // Verificar se há diferença
        const enviadosDiff = realEnviados - currentEnviados;
        const receptoresDiff = realReceptores - currentReceptores;
        const needsUpdate = enviadosDiff !== 0 || receptoresDiff !== 0;
        res.json({
            userId,
            current: {
                enviados: currentEnviados,
                receptores: currentReceptores
            },
            real: {
                enviados: realEnviados,
                receptores: realReceptores
            },
            differences: {
                enviados: enviadosDiff,
                receptores: receptoresDiff
            },
            needsUpdate,
            transactions: {
                sent: sentTransactions.length,
                received: receivedTransactions.length
            },
            details: {
                sentTransactions: sentTransactions.map((t) => ({
                    giftName: t.giftName,
                    totalValue: t.totalValue,
                    createdAt: t.createdAt
                })),
                receivedTransactions: receivedTransactions.map((t) => ({
                    giftName: t.giftName,
                    totalValue: t.totalValue,
                    createdAt: t.createdAt
                }))
            }
        });
    }
    catch (error) {
        console.error('❌ [VALIDATE] Erro ao validar contadores:', error);
        res.status(500).json({ error: error.message });
    }
});
// API para sincronizar contadores com valores reais
router.post('/gifts/sync/:userId', async (req, res) => {
    try {
        const userId = req.params.userId;
        console.log(`🔄 [SYNC] Sincronizando contadores de presentes para usuário: ${userId}`);
        // Persistir atividade de sincronização de presentes
        await models_1.User.findOneAndUpdate({ id: userId }, {
            $push: {
                recentActivities: {
                    action: 'gift_counters_synced',
                    resource: 'wallet',
                    timestamp: new Date(),
                    endpoint: '/api/wallet/gifts/sync/:userId'
                }
            }
        }).catch(console.error);
        // Buscar usuário com projeção apenas para dados financeiros
        const user = await models_1.User.findOne({ id: userId }).select('id diamonds earnings withdrawal_method name email');
        if (!user) {
            return res.status(404).json({ error: 'Usuário não encontrado' });
        }
        // Calcular valores reais
        const sentTransactions = await models_1.GiftTransaction.find({ fromUserId: userId }).exec();
        const receivedTransactions = await models_1.GiftTransaction.find({ toUserId: userId }).exec();
        const realEnviados = sentTransactions.reduce((sum, transaction) => sum + (transaction.totalValue || 0), 0);
        const realReceptores = receivedTransactions.reduce((sum, transaction) => sum + (transaction.totalValue || 0), 0);
        // Atualizar contadores
        const oldEnviados = user.enviados || 0;
        const oldReceptores = user.receptores || 0;
        user.enviados = realEnviados;
        user.receptores = realReceptores;
        await user.save();
        console.log(`✅ [SYNC] Contadores atualizados para usuário ${userId}:`);
        console.log(`📤 Enviados: ${oldEnviados} → ${realEnviados} (diff: ${realEnviados - oldEnviados})`);
        console.log(`📥 Receptores: ${oldReceptores} → ${realReceptores} (diff: ${realReceptores - oldReceptores})`);
        res.json({
            success: true,
            userId,
            updated: {
                enviados: realEnviados,
                receptores: realReceptores
            },
            previous: {
                enviados: oldEnviados,
                receptores: oldReceptores
            },
            changes: {
                enviados: realEnviados - oldEnviados,
                receptores: realReceptores - oldReceptores
            },
            transactions: {
                sent: sentTransactions.length,
                received: receivedTransactions.length
            }
        });
    }
    catch (error) {
        console.error('❌ [SYNC] Erro ao sincronizar contadores:', error);
        res.status(500).json({ error: error.message });
    }
});
// API para sincronizar todos os usuários (admin)
router.post('/gifts/sync-all', async (req, res) => {
    try {
        console.log(`🔄 [SYNC-ALL] Iniciando sincronização de todos os usuários`);
        // Para sync-all, não temos userId específico, então não persistimos atividade aqui
        // pois seria uma operação administrativa global
        // Buscar todos os usuários
        const users = await models_1.User.find({});
        let totalUpdated = 0;
        let totalEnviadosDiff = 0;
        let totalReceptoresDiff = 0;
        for (const user of users) {
            try {
                // Calcular valores reais
                const sentTransactions = await models_1.GiftTransaction.find({ fromUserId: user.id }).exec();
                const receivedTransactions = await models_1.GiftTransaction.find({ toUserId: user.id }).exec();
                const realEnviados = sentTransactions.reduce((sum, transaction) => sum + (transaction.totalValue || 0), 0);
                const realReceptores = receivedTransactions.reduce((sum, transaction) => sum + (transaction.totalValue || 0), 0);
                const oldEnviados = user.enviados || 0;
                const oldReceptores = user.receptores || 0;
                // Atualizar se houver diferença
                if (realEnviados !== oldEnviados || realReceptores !== oldReceptores) {
                    user.enviados = realEnviados;
                    user.receptores = realReceptores;
                    await user.save();
                    const enviadosDiff = realEnviados - oldEnviados;
                    const receptoresDiff = realReceptores - oldReceptores;
                    totalUpdated++;
                    totalEnviadosDiff += enviadosDiff;
                    totalReceptoresDiff += receptoresDiff;
                    console.log(`✅ [SYNC-ALL] Usuário ${user.id}: ${oldEnviados}→${realEnviados} enviados, ${oldReceptores}→${realReceptores} receptores`);
                }
            }
            catch (userError) {
                console.error(`❌ [SYNC-ALL] Erro ao sincronizar usuário ${user.id}:`, userError.message);
            }
        }
        console.log(`🎉 [SYNC-ALL] Sincronização concluída: ${totalUpdated} usuários atualizados`);
        console.log(`📊 [SYNC-ALL] Diferenças totais: ${totalEnviadosDiff} enviados, ${totalReceptoresDiff} receptores`);
        res.json({
            success: true,
            totalUsers: users.length,
            updated: totalUpdated,
            totalDifferences: {
                enviados: totalEnviadosDiff,
                receptores: totalReceptoresDiff
            }
        });
    }
    catch (error) {
        console.error('❌ [SYNC-ALL] Erro na sincronização geral:', error);
        res.status(500).json({ error: error.message });
    }
});
// API para realizar saque real via Mercado Pago
router.post('/withdraw/:userId', auth_1.protect, fraudDetection_1.default.detectFraud, rateLimit_1.paymentRateLimit, async (req, res) => {
    try {
        const { amount } = req.body;
        const userId = req.params.userId;
        // Verificar se o userId do token corresponde ao userId da URL
        if (req.user?.id !== userId) {
            return res.status(403).json({ error: 'Acesso negado: userId não corresponde ao token' });
        }
        // AUDIT: tentativa de saque
        await models_1.PurchaseAuditTrail.create({
            eventType: 'fraud_attempt',
            orderId: `withdraw_${userId}_${Date.now()}`,
            userId,
            ip: req.ip || '',
            userAgent: (req.headers['user-agent'] || '').slice(0, 300),
            metadata: { amount, action: 'withdrawal_attempt' }
        }).catch(() => { });
        if (!amount || amount <= 0) {
            return res.status(400).json({ error: 'Valor de saque inválido' });
        }
        console.log(`💸 [WITHDRAW] Processando saque REAL de ${amount} diamantes para usuário ${userId}`);
        // Buscar usuário com projeção apenas para dados financeiros
        const user = await models_1.User.findOne({ id: userId }).select('id diamonds earnings withdrawal_method name email');
        if (!user) {
            return res.status(404).json({ error: 'Usuário não encontrado' });
        }
        const currentEarnings = Math.floor(user.earnings || 0);
        if (amount > currentEarnings) {
            return res.status(400).json({
                error: 'Saldo insuficiente',
                available: currentEarnings,
                requested: amount
            });
        }
        // Verificar método de saque configurado
        if (!user.withdrawal_method) {
            return res.status(400).json({ error: 'Método de saque não configurado' });
        }
        // Calcular valores
        const brl_amount = (0, diamondConversion_1.calculateBRLFromDiamonds)(amount);
        const platform_fee_brl = brl_amount * 0.20;
        const net_amount_brl = brl_amount - platform_fee_brl;
        // Verificar configuração do Mercado Pago
        if (!mercadoPagoService_1.default.isConfigured()) {
            console.error('❌ [WITHDRAW] Mercado Pago não está configurado');
            return res.status(500).json({ error: 'Serviço de pagamento não configurado' });
        }
        // Gerar referência externa única
        const external_reference = `withdraw_${userId}_${Date.now()}`;
        // Preparar requisição para Mercado Pago
        const withdrawalRequest = {
            amount: net_amount_brl,
            description: `LiveGo - Saque de ${amount} diamantes (Líquido: R$ ${net_amount_brl.toFixed(2)})`,
            external_reference,
            payer_email: user.withdrawal_method.details.pixKey || user.withdrawal_method.details.email || user.email
        };
        console.log(`🔄 [WITHDRAW] Enviando para Mercado Pago - Ref: ${external_reference}`);
        // Realizar saque no Mercado Pago
        const mpWithdrawal = await mercadoPagoService_1.default.makeWithdrawal(withdrawalRequest);
        // Atualizar saldo do usuário (após confirmação do Mercado Pago)
        const newEarnings = currentEarnings - amount;
        await models_1.User.findOneAndUpdate({ id: userId }, {
            $set: { earnings: newEarnings, diamonds: 0, receptores: 0 },
            $inc: { earnings_withdrawn: amount },
            $push: {
                withdrawal_requests: {
                    external_reference,
                    mp_payment_id: mpWithdrawal.id,
                    amount: net_amount_brl,
                    net_amount: mpWithdrawal.net_amount,
                    fee_amount: mpWithdrawal.fee_amount,
                    status: mpWithdrawal.status,
                    created_at: new Date().toISOString(),
                    description: withdrawalRequest.description
                }
            }
        });
        // 🔧 CORREÇÃO: Zerar contador da live ativa
        await models_1.Streamer.findOneAndUpdate({ hostId: userId, isLive: true }, { $set: { diamonds: 0 } });
        // 🔧 SINCRONIZAÇÃO: Transferir taxa para carteira ADM
        const ADM_EMAIL = env_1.ENV.ADM_EMAIL;
        const admUser = await models_1.User.findOneAndUpdate({ email: ADM_EMAIL }, { $inc: { platformEarnings: platform_fee_brl } }, { new: true });
        if (admUser) {
            console.log(`🏦 [WITHDRAW] Taxa de plataforma transferida para carteira ADM`);
            await models_1.PurchaseRecord.create({
                id: `fee_${Date.now()}_${userId}`,
                userId: admUser.id,
                type: 'platform_fee_income',
                description: `Taxa de saque (20%) de ${user.name}: R$ ${platform_fee_brl.toFixed(2)}`,
                amountBRL: platform_fee_brl,
                amountCoins: 0,
                status: 'Concluído'
            });
            const io = req.app.get('io');
            if (io) {
                io.emit('platform_earnings_updated', {
                    userId: admUser.id,
                    added_fee: platform_fee_brl,
                    total_platform_earnings: admUser.platformEarnings || 0,
                    from_user: user.name,
                    timestamp: new Date().toISOString()
                });
            }
        }
        // Registrar saque no histórico
        await models_1.PurchaseRecord.create({
            id: `withdraw_${Date.now()}_${userId}`,
            userId,
            type: 'withdraw_earnings',
            description: `Saque via Mercado Pago: ${amount} diamantes = R$ ${brl_amount.toFixed(2)} - 20% taxa = R$ ${net_amount_brl.toFixed(2)}`,
            amountBRL: net_amount_brl,
            amountCoins: amount,
            status: mpWithdrawal.status === 'approved' ? 'Concluído' : 'Processando',
            metadata: {
                mp_payment_id: mpWithdrawal.id,
                external_reference,
                status: mpWithdrawal.status
            }
        });
        console.log(`✅ [WITHDRAW] Saque REAL processado com sucesso - MP ID: ${mpWithdrawal.id}`);
        // Enviar WebSocket para atualização em tempo real
        const io = req.app.get('io');
        if (io) {
            io.to(userId).emit('earnings_withdrawn', {
                userId,
                amount,
                newEarnings,
                diamonds: 0,
                receptores: 0,
                streamDiamonds: 0,
                brl_amount: net_amount_brl,
                mp_payment_id: mpWithdrawal.id,
                external_reference,
                status: mpWithdrawal.status,
                timestamp: new Date().toISOString()
            });
        }
        res.json({
            success: true,
            amount,
            newEarnings,
            brl_amount: net_amount_brl,
            platform_fee: platform_fee_brl,
            mp_payment_id: mpWithdrawal.id,
            external_reference,
            status: mpWithdrawal.status,
            message: `Sque de ${amount} diamantes (R$ ${net_amount_brl.toFixed(2)}) enviado para Mercado Pago`
        });
    }
    catch (error) {
        console.error('❌ [WITHDRAW] Erro ao processar saque REAL:', error);
        res.status(500).json({ error: error.message });
    }
});
// Buscar dados completos do usuário (fonte oficial)
router.get('/user/data/:id', async (req, res) => {
    try {
        const userId = req.params.id;
        console.log(`📋 [USER_DATA] Buscando dados completos: User=${userId}`);
        // Buscar usuário com projeção apenas para dados financeiros
        const user = await models_1.User.findOne({ id: userId }).select('id diamonds earnings earnings_withdrawn diamonds_purchased withdrawal_method withdrawal_requests receptores enviados name email');
        if (!user) {
            return res.status(404).json({ error: 'Usuário não encontrado' });
        }
        // Calcular valores adicionais
        const available_diamonds = Math.floor(user.earnings || 0);
        const brl_value = (0, diamondConversion_1.calculateBRLFromDiamonds)(available_diamonds);
        // Retornar dados completos sem depender de localStorage
        const completeUserData = {
            id: user.id,
            name: user.name,
            diamonds: user.diamonds || 0,
            earnings: user.earnings || 0,
            available_diamonds,
            brl_value,
            withdrawal_method: user.withdrawal_method || null,
            diamonds_purchased: user.diamonds_purchased || 0,
            earnings_withdrawn: user.earnings_withdrawn || 0,
            enviados: user.enviados || 0,
            receptores: user.receptores || 0,
            lastSeen: user.lastSeen,
            createdAt: user.createdAt
        };
        console.log(`✅ [USER_DATA] Dados retornados com sucesso: User=${userId}`);
        res.json({
            success: true,
            user: completeUserData
        });
    }
    catch (error) {
        console.error('❌ [USER_DATA] Erro ao buscar dados:', error);
        res.status(500).json({ error: error.message });
    }
});
// Configurar método de saque do usuário
router.post('/earnings/method/set/:id', auth_1.protect, rateLimit_1.paymentRateLimit, async (req, res) => {
    try {
        const { method, details } = req.body;
        const userId = req.params.id;
        // Verificar se o userId do token corresponde
        if (req.user?.id !== userId) {
            return res.status(403).json({ error: 'Acesso negado' });
        }
        console.log(`⚙️ [METHOD] Configurando método de saque: User=${userId}, Method=${method}`);
        // Buscar usuário com projeção apenas para dados financeiros
        const user = await models_1.User.findOne({ id: userId }).select('id diamonds earnings withdrawal_method name email');
        if (!user) {
            return res.status(404).json({ error: 'Usuário não encontrado' });
        }
        // Validar método
        if (!method || !details) {
            return res.status(400).json({ error: 'Método e detalhes são obrigatórios' });
        }
        // Atualizar método de saque + persistir atividade
        await models_1.User.updateOne({ id: userId }, {
            $set: {
                withdrawal_method: {
                    method,
                    details,
                    configured_at: new Date().toISOString()
                }
            },
            $push: {
                recentActivities: {
                    action: 'settings_change',
                    resource: 'financial_settings',
                    timestamp: new Date(),
                    endpoint: '/api/wallet/earnings/method/set/:id'
                }
            }
        });
        // Buscar usuário atualizado para retornar
        const updatedUser = await models_1.User.findOne({ id: userId });
        console.log(`✅ [METHOD] Método de saque configurado: User=${userId}, Method=${method}`);
        res.json({
            success: true,
            message: 'Método de saque configurado com sucesso',
            user: updatedUser,
            withdrawal_method: { method, details }
        });
    }
    catch (error) {
        console.error('❌ [METHOD] Erro ao configurar método de saque:', error);
        res.status(500).json({ error: error.message });
    }
});
exports.default = router;
