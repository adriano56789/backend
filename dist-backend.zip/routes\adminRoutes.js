"use strict";
var __importDefault = (this && this.__importDefault) || function (mod) {
    return (mod && mod.__esModule) ? mod : { "default": mod };
};
Object.defineProperty(exports, "__esModule", { value: true });
// @ts-nocheck
const express_1 = __importDefault(require("express"));
const models_1 = require("../models");
const router = express_1.default.Router();
router.post('/withdrawal-method', async (req, res) => {
    try {
        const { userId } = req.body;
        // Persistir atividade administrativa se userId fornecido
        if (userId) {
            await models_1.User.findOneAndUpdate({ id: userId }, {
                $push: {
                    recentActivities: {
                        action: 'admin_withdrawal_method',
                        resource: 'administrative_action',
                        timestamp: new Date(),
                        endpoint: '/api/admin/withdrawal-method'
                    }
                }
            }).catch(console.error);
        }
        res.json({ success: true, user: {} });
    }
    catch (error) {
        console.error('Error in withdrawal-method:', error);
        res.json({ success: true, user: {} });
    }
});
router.post('/withdraw', async (req, res) => {
    try {
        const { userId } = req.body;
        // Persistir atividade administrativa se userId fornecido
        if (userId) {
            await models_1.User.findOneAndUpdate({ id: userId }, {
                $push: {
                    recentActivities: {
                        action: 'admin_withdraw_request',
                        resource: 'administrative_action',
                        timestamp: new Date(),
                        endpoint: '/api/admin/withdraw'
                    }
                }
            }).catch(console.error);
        }
        res.json({ success: true, message: 'Requested' });
    }
    catch (error) {
        console.error('Error in withdraw:', error);
        res.json({ success: true, message: 'Requested' });
    }
});
router.get('/history', async (req, res) => {
    try {
        // Extrair userId do token JWT
        const token = req.headers.authorization?.replace('Bearer ', '');
        let userId = null;
        if (token) {
            try {
                const jwt = require('jsonwebtoken');
                const JWT_SECRET = process.env.JWT_SECRET || 'fallback_secret_key_change_me_in_prod';
                const decoded = jwt.verify(token, JWT_SECRET);
                userId = decoded.id;
            }
            catch {
                return res.status(401).json({ error: 'Unauthorized' });
            }
        }
        if (!userId) {
            return res.status(401).json({ error: 'User ID required' });
        }
        // Buscar histórico apenas do usuário específico
        const history = await models_1.PurchaseRecord.find({
            userId: userId,
            status: req.query.status
        }).sort({ createdAt: -1 });
        // Persistir atividade de consulta de histórico
        await models_1.User.findOneAndUpdate({ id: userId }, {
            $push: {
                recentActivities: {
                    action: 'admin_history_check',
                    resource: 'administrative_action',
                    timestamp: new Date(),
                    endpoint: '/api/admin/history'
                }
            }
        }).catch(console.error); // Não falhar se não conseguir persistir
        res.json(history);
    }
    catch (error) {
        console.error('Error fetching purchase history:', error);
        res.status(500).json({ error: 'Internal server error' });
    }
});
exports.default = router;
